require 'rails_helper'

RSpec.describe CommentsController, type: :controller do

end
