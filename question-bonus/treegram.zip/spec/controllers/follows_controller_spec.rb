require 'rails_helper'

RSpec.describe FollowsController, type: :controller do

end
